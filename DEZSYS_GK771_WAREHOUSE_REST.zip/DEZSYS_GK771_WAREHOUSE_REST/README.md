# Middleware Engineering "REST and Data Formats"

## Aufgabenstellung

## Implementierung

## Quellen
